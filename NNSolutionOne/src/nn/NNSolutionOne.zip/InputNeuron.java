package nn;

public class InputNeuron extends BaseNeuron {
	
	public InputNeuron() {
		
	}
	
	@Override
	public String listWeights() {
		return "";
		
	}
		
	
}
